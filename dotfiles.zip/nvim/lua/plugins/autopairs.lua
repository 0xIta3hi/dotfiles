return {
  {
    "windwp/nvim-autopairs",
    event = "InsertEnter",
    opts = {} -- This installs with default settings
  },
}
