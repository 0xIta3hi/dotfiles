return {
  {
    "nvimtools/none-ls.nvim",
    dependencies = { "nvim-lua/plenary.nvim" },
    config = function()
      local null_ls = require("none-ls")
      null_ls.setup({
        sources = {
          null_ls.builtins.formatting.black,        -- Python
          null_ls.builtins.formatting.clang_format, -- C/C++
          null_ls.builtins.formatting.prettier,     -- JS/TS
        },
      })
      -- Format on save
      vim.api.nvim_create_autocmd("BufWritePre", {
        callback = function()
          vim.lsp.buf.format({ async = false })
        end,
      })
    end,
  },
}
