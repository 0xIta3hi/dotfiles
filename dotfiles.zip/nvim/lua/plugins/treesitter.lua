return {
  {
    "nvim-treesitter/nvim-treesitter",
    build = ":TSUpdate",
    main = "nvim-treesitter.configs", -- This tells Lazy where to look for setup
    opts = {
      -- Add languages you use here
      ensure_installed = { 
        "lua", "vim", "vimdoc", "bash", "python", 
        "markdown", "markdown_inline", "hyprlang" -- Added hyprlang for your rice!
      },
      highlight = { 
        enable = true,
        additional_vim_regex_highlighting = false,
      },
      indent = { enable = true },
    },
  },
}
