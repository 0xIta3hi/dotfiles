return {
  {
    "NvChad/nvim-colorizer.lua",
    config = function()
      require("colorizer").setup({
        user_default_options = {
          tailwind = true, -- If you do web dev
          sass = true,
          mode = "background", -- "foreground" or "background"
        },
      })
    end,
  },
}
