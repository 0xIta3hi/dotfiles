-- ~/.config/nvim/lua/plugins/theme.lua
return {
  {
    "rebelot/kanagawa.nvim",
    name = "kanagawa",
    priority = 1000,
    config = function()
      require("kanagawa").setup({
        theme = "dragon",        -- wave, dragon, lotus
        transparent = false,    -- keeps your transparent bg
        terminalColors = true,
      })
      vim.cmd.colorscheme("kanagawa")
    end,
  },
}
