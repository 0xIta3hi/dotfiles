return {
  {
    "folke/snacks.nvim",
    priority = 1000,
    lazy = false,
    opts = {
      dashboard = { enabled = true },
      indent = { enabled = true },
      input = { enabled = true },
      notifier = { enabled = true },
      scope = { enabled = true },
      scroll = { enabled = true },
      statuscolumn = { enabled = true },
      words = { enabled = true },
    },
    keys = {
      { "<leader>f", function() Snacks.picker.files() end, desc = "Find Files" },
      { "<leader>g", function() Snacks.lazygit() end, desc = "Lazygit" },
      { "<leader>t", function() Snacks.terminal() end, desc = "Terminal" },
    },
  },
}
