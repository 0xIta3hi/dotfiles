-- ~/.config/nvim/lua/config/options.lua
vim.g.mapleader = " "
vim.g.maplocalleader = " "

local opt = vim.opt

opt.number = true           -- Show line numbers
opt.relativenumber = true   -- Relative line numbers (great for movement)
opt.splitright = true       -- Vertical splits to the right
opt.splitbelow = true       -- Horizontal splits to the bottom
opt.ignorecase = true       -- Ignore case in search
opt.smartcase = true        -- ...unless uppercase is used
opt.termguicolors = true    -- True color support
opt.cursorline = true       -- Highlight the current line
opt.shiftwidth = 2          -- Size of an indent
opt.tabstop = 2             -- Number of spaces tabs count for
opt.expandtab = true        -- Use spaces instead of tabs

-- Fix clipboard for Hyprland (Wayland)
vim.opt.clipboard = "unnamedplus"
